from flask import render_template, flash, redirect, url_for
from app import app, db
from app.forms import LoginForm, RegistrationForm
from flask_login import current_user, login_user, logout_user
from app.models import User
from flask_login import login_required
from flask import request
from werkzeug.urls import url_parse
import requests
from bs4 import BeautifulSoup
import re
@app.route('/')
@app.route('/index')
def connect(url: str):
    r = requests.get(url)
    if r.status_code == 200:
        return r.text
    else:
        return
def remove_all_tabs_station_name(string):
    pattern = re.compile(r'[А-Яа-яёЁ0-9 ]+')
    return pattern.findall(string)[0].strip()

def phone_string_correct(phone):
    pattern = re.compile(r'\+7 \([0-9]{3}\) [0-9]{3}-[0-9]{2}-[0-9]{2}')
    return pattern.search(phone).group()
def find_all_theaters(soup_karo):
    theaters_dict = dict()
    metro_class = 'cinemalist__cinema-item__metro__station-list__station-item'
    theaters_class = 'cinemalist__cinema-item'
    theaters = soup_karo.findAll('li', class_=theaters_class)
    for theater in theaters:
        theaters_dict[theater.findAll('h4')[0].text] = {
            'metro': [remove_all_tabs_station_name(i.text) for i in theater.findAll('li', class_=metro_class)],
            'address': theater['data-address'].split('Тел.:')[0].strip(),
            'phone': phone_string_correct(theater['data-address'].split('Тел.:')[-1]),
            'id': theater['data-id'],
            'data-url': theater['data-url']
        }
    return theaters_dict
def find_cinemas(url):
    r = connect(url)
    if r:
        cinemas_dict = dict()
        soup = BeautifulSoup(r, "html.parser")
        cinemas = soup.findAll('div', class_='cinema-page-item__schedule__row')
        for cinema in cinemas:
            try:
                title = ','.join(cinema.findAll('h3')[0].text.split(',')[:-1]).strip()
                age = cinema.findAll('h3')[0].text.split(',')[-1].strip()
                cinemas_dict[title] = {
                    'age': None,
                    'items': {}
                }
                cinemas_dict[title]['age'] = age
                items = cinema.findAll('div', class_='cinema-page-item__schedule__row__board-row')
                for item in items:
                    type_ = item.findAll('div', class_='cinema-page-item__schedule__row__board-row__left')[0].text.strip()
                    cinemas_dict[title]['items'][type_] = []
                    items_times = item.findAll('a', class_='karo-wi-button sessionButton ')
                    for timer in items_times:
                        cinemas_dict[title]['items'][type_].append(timer.text.strip())
            except:
                print(cinema)
        return cinemas_dict
    else:
        return
@app.route('/')
@app.route('/index')
def main():
    main_url = 'https://karofilm.ru'
    theaters = requests.get(main_url + '/theatres')
    soup_theaters = BeautifulSoup(theaters.text, "html.parser")
    theaters_dicts = find_all_theaters(soup_theaters)
    for k, v in list(theaters_dicts.items()):
        theaters_dicts[k]['cinemas'] = find_cinemas(main_url+v['data-url'])
    return theaters_dicts
    return render_template('index.html', title='Home',main = main)
    
    
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            flash("Invalid password or username")
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        return redirect(url_for('index'))
    return render_template('login.html', title='Sign In', form=form)
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password')
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('index')
        return redirect(next_page)

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.route('/user/<username>')
@login_required
def user(username):
    user = User.query.filter_by(username=username).first_or_404()
    posts = [
        {'author': user, 'body': 'Test post #1'},
        {'author': user, 'body': 'Test post #2'}
    ]
    return render_template('user.html', user=user, posts=posts)